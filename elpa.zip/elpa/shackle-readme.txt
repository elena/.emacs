This global minor mode allows you to easily set up rules for
popups in Emacs.

See the README for more info: https://depp.brause.cc/shackle
