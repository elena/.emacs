The Emacs Lisp Python Environment in Emacs

Elpy is an Emacs package to bring powerful Python editing to Emacs.
It combines a number of existing Emacs packages, both written in
Emacs Lisp as well as Python.

For more information, read the Elpy manual:

https://elpy.readthedocs.io/en/latest/index.html
