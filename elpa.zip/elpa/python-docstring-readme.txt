python-docstring-mode.el is a minor mode for intelligently
reformatting (refilling) and highlighting Python docstrings. It
understands both epytext and Sphinx formats (even intermingled!),
so it knows how to reflow them correctly. It will also highlight
markup in your docstrings, including epytext and reStructuredText.
