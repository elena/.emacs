Copyright 2013 The go-mode Authors.  All rights reserved.
Use of this source code is governed by a BSD-style
license that can be found in the LICENSE file.

Author: The go-mode Authors
Version: 1.5.0
Keywords: languages go
URL: https://github.com/dominikh/go-mode.el

This file is not part of GNU Emacs.
