Simple package to be to be able to control `manage.py', the standard
file that every Django project comes with.  You are able to call any
command with `django-manage-command' plus it comes with code
completion so third party plugins will also be completed.
