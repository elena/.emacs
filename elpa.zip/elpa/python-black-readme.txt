Commands for reformatting Python code via black (and black-macchiato).
