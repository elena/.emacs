This mode lets you edit the window configuration interactively just
by using the keyboard.

To use it, type M-x windresize; this puts Emacs in a state
where the up/down and left/right arrow keys resize the window
dimensions.  To return Emacs to its ordinary state, type RET.

See the docstring of `windresize' for a detailed description of the
other commands that are available while windresize is active.
