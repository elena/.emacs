See the file README.md in `workgroups.el's directory

Installation:
