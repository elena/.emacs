To use this file, put something like the following in your
~/.emacs:

(add-to-list 'load-path "/directory/containing/neotree/")
(require 'neotree)

Type M-x neotree to start.

To set options for NeoTree, type M-x customize, then select
Applications, NeoTree.
