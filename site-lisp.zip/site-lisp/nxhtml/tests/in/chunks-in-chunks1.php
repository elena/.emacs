$a = <<<EOTHTML

<p>stuff</p>

EOTHTML;


$b = <<<EOT

    <h2><a href="/">stuff</a></h2>

EOT;

$c = <<<EOT

<button onclick="a()">test</button>


EOT;
