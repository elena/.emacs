# -*- Python -*-


"""
===============
This is a title
===============

This is some general description
"""


class SomeClass(object):
    """
    This is a class description.
    """

    def __init__(self, fileName):
        """The constructor."""
        pass

    def oneMethod():
        pass
