
<p>
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  <?php
    fun();
  ?>
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
  Some text to wrap.
</p>
