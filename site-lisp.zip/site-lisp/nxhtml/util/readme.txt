This subdirectory contains files used by nXhtml that I have
written. The files are placed here because they may be of use also
outside of nXhtml.
